﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Reflection;

namespace инд4_Рубцова
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dataGridView1.Columns.Add("каталог", "Номер диска");
            dataGridView1.Columns.Add("каталог", "Название Компакт-диска");
            dataGridView1.Columns.Add("название", "Название песни");
            dataGridView1.Columns.Add("песни", "Исполнитель песни");          
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        Hashtable has = new Hashtable();


        private void button3_Click(object sender, EventArgs e)
        {
             
                  
            string num = Convert.ToString(numericUpDown1.Value);
            string name = textBox4.Text;
            string pes = textBox5.Text;
            string isp = textBox1.Text;         
            if (num != "" && name != "" && pes != "" && isp != "")
            {
                if (!has.ContainsKey(num))
                {
                    has.Add(num, new ArrayList());
                    ArrayList names = (ArrayList)has[num];
                    names.Add(name);
                    names.Add(pes);
                    names.Add(isp);
                    dataGridView1.Rows.Add(num, name, pes, isp);
                }
                else MessageBox.Show("Диск с таким наполнением уже существует!", "Ошибка", MessageBoxButtons.OK);
            }
            else MessageBox.Show("Заполните все поля!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a = dataGridView1.CurrentRow.Index;
            string name = dataGridView1.Rows[a].Cells[0].Value.ToString();
            has.Remove(name);
            dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string name = textBox2.Text;
            var r = dataGridView1.Rows
                 .Cast<DataGridViewRow>()
                 .Where(row => row.Cells[1].Value != null && row.Cells[1].Value.ToString() == name);
            foreach (var row in r)
            {
                row.DefaultCellStyle.BackColor = Color.Red;
            }
        }
    }
}
